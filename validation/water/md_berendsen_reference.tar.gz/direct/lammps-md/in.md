units real
atom_style charge
boundary p p p
read_data atoms.data
pair_style reaxff NULL tabulate 0 enobonds yes
pair_coeff * * ffield O H
fix charges all qeq/reaxff 1 0 10 1e-12 reaxff maxiter 2000
neighbor 0.6 bin
neigh_modify every 1 delay 0 check yes
timestep 0.25
fix integrator all nve
fix thermostat all temp/berendsen 300 300 100
compute_modify thermostat_temp extra/dof 0
thermo_style custom step temp pe
compute_modify thermo_temp extra/dof 0
thermo_modify format float %.17g
thermo 2000
run 100
reset_timestep 0
dump samples all custom 2000 md.dump id xu yu zu q fx fy fz vx vy vz
dump_modify samples sort id format float %.17g
run 4000
write_dump all custom final.dump id xu yu zu q fx fy fz vx vy vz modify sort id format float %.17g
