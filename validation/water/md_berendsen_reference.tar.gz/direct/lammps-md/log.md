LAMMPS (22 Jul 2025 - Update 4)
units real
atom_style charge
boundary p p p
read_data atoms.data
Reading data file ...
  triclinic box = (0 0 0) to (12.48 12.48 12.48) with tilt (0 0 0)
  1 by 1 by 1 MPI processor grid
  reading atoms ...
  192 atoms
  reading velocities ...
  192 velocities
  read_data CPU = 0.001 seconds
pair_style reaxff NULL tabulate 0 enobonds yes
pair_coeff * * ffield O H
WARNING: Changed valency_val to valency_boc for X (src/REAXFF/reaxff_ffield.cpp:300)
fix charges all qeq/reaxff 1 0 10 1e-12 reaxff maxiter 2000
neighbor 0.6 bin
neigh_modify every 1 delay 0 check yes
timestep 0.25
fix integrator all nve
fix thermostat all temp/berendsen 300 300 100
compute_modify thermostat_temp extra/dof 0
thermo_style custom step temp pe
compute_modify thermo_temp extra/dof 0
thermo_modify format float %.17g
thermo 2000
run 100
Neighbor list info ...
  update: every = 1 steps, delay = 0 steps, check = yes
  max neighbors/atom: 2000, page size: 100000
  master list distance cutoff = 10.6
  ghost atom cutoff = 10.6
  binsize = 5.3, bins = 3 3 3
  2 neighbor lists, perpetual/occasional/extra = 2 0 0
  (1) pair reaxff, perpetual
      attributes: half, newton off, ghost
      pair build: half/bin/ghost/newtoff
      stencil: full/ghost/bin/3d
      bin: standard
  (2) fix qeq/reaxff, perpetual, copy from (1)
      attributes: half, newton off
      pair build: copy
      stencil: none
      bin: none
Per MPI rank memory allocation (min/avg/max) = 65.54 | 65.54 | 65.54 Mbytes
   Step          Temp          PotEng    
         0  299.9995320689369 -16017.189296170218
       100  592.9759677900621 -16206.333065358611
Loop time of 3.52406 on 1 procs for 100 steps with 192 atoms

Performance: 0.613 ns/day, 39.156 hours/ns, 28.376 timesteps/s, 5.448 katom-step/s
99.5% CPU use with 1 MPI tasks x no OpenMP threads

MPI task timing breakdown:
Section |  min time  |  avg time  |  max time  |%varavg| %total
---------------------------------------------------------------
Pair    | 1.8561     | 1.8561     | 1.8561     |   0.0 | 52.67
Neigh   | 0.15311    | 0.15311    | 0.15311    |   0.0 |  4.34
Comm    | 0.0019333  | 0.0019333  | 0.0019333  |   0.0 |  0.05
Output  | 1.0333e-05 | 1.0333e-05 | 1.0333e-05 |   0.0 |  0.00
Modify  | 1.5125     | 1.5125     | 1.5125     |   0.0 | 42.92
Other   |            | 0.0004093  |            |       |  0.01

Nlocal:            192 ave         192 max         192 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Nghost:           3742 ave        3742 max        3742 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Neighs:          81665 ave       81665 max       81665 min
Histogram: 1 0 0 0 0 0 0 0 0 0

Total # of neighbors = 81665
Ave neighs/atom = 425.33854
Neighbor list builds = 7
Dangerous builds = 0
reset_timestep 0
dump samples all custom 2000 md.dump id xu yu zu q fx fy fz vx vy vz
dump_modify samples sort id format float %.17g
run 4000
Per MPI rank memory allocation (min/avg/max) = 65.54 | 65.54 | 65.54 Mbytes
   Step          Temp          PotEng    
         0  592.97596779006221 -16206.333065358613
      2000  361.55449960097837 -16409.368210742319
      4000  298.07465456422045 -16419.145955954322
Loop time of 127.722 on 1 procs for 4000 steps with 192 atoms

Performance: 0.676 ns/day, 35.478 hours/ns, 31.318 timesteps/s, 6.013 katom-step/s
95.0% CPU use with 1 MPI tasks x no OpenMP threads

MPI task timing breakdown:
Section |  min time  |  avg time  |  max time  |%varavg| %total
---------------------------------------------------------------
Pair    | 68.397     | 68.397     | 68.397     |   0.0 | 53.55
Neigh   | 3.7151     | 3.7151     | 3.7151     |   0.0 |  2.91
Comm    | 0.064431   | 0.064431   | 0.064431   |   0.0 |  0.05
Output  | 0.0042747  | 0.0042747  | 0.0042747  |   0.0 |  0.00
Modify  | 55.529     | 55.529     | 55.529     |   0.0 | 43.48
Other   |            | 0.01192    |            |       |  0.01

Nlocal:            192 ave         192 max         192 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Nghost:           3606 ave        3606 max        3606 min
Histogram: 1 0 0 0 0 0 0 0 0 0
Neighs:          80397 ave       80397 max       80397 min
Histogram: 1 0 0 0 0 0 0 0 0 0

Total # of neighbors = 80397
Ave neighs/atom = 418.73438
Neighbor list builds = 192
Dangerous builds = 0
write_dump all custom final.dump id xu yu zu q fx fy fz vx vy vz modify sort id format float %.17g
Total wall time: 0:02:11
